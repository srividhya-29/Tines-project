   
from TinesMethods import getHTTPRequest
from TinesMethods import getAgentType
from TinesMethods import printFinalMessage
from TinesMethods import loadJSON
from TinesMethods import generateDotNotation
import unittest2 as unittest
import Constants

class test_Tines(unittest.TestCase):
    def test_getHTTPRequest(self):
        response = getHTTPRequest(url = "http://free.ipwhois.io/json/")
        self.assertIsNotNone(response)

    def test_getAgentType(self):
        agent = {
      "type": "HTTPRequestAgent",
      "name": "fact",
      "options": {"url": "http://numbersapi.com/{{datetime.day_of_year}}/date?json"}}
        agentType = getAgentType(agent)
        self.assertEqual(agentType,Constants.HTTPREQUESTAGENT)
    
    def test_loadJSON(self):
        file = "tiny-tines-today.json"
        with open(file,'r') as f:
            data = loadJSON(f)
            self.assertIsNotNone(data)
    
    def test_generateDotNotation(self):
        patternArray = ['element1','element2']
        result = generateDotNotation(patternArray)
        self.assertEqual(result['pattern'],"{{element1.element2}}")