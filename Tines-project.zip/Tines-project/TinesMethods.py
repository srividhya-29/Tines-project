import Constants
import requests
import re
import json

def loadJSON(file):
    data = json.load(file)
    if data != None:
        agents = data[Constants.AGENTS]
        return agents
    else:
        agents = None
        

def getHTTPRequest(url): 
    r = requests.get(url = url)
    data = None
    if(r.status_code >= Constants.STATUSCODE_200 and r.status_code < Constants.STATUSCODE_300):
        try:
            data = r.json() 
        except ValueError:
            print(Constants.INVALID_JSON_MESSAGE)
        finally:
             return data

def generateDotNotation(rootElement,e = None):
     j =0
     returnValue = {'pattern':"",'paramValue':""}
     returnValue['paramvalue'] = e[rootElement[j]] if e != None else ""
     returnValue['pattern'] = "{{" +rootElement[j]+"."
     while(j < len(rootElement)-1):
         j = j+1
         returnValue['pattern'] = returnValue['pattern'] +rootElement[j]+"."
         returnValue['paramvalue'] = returnValue['paramvalue'][rootElement[j]] if e!= None else ""
     last_char_index = returnValue['pattern'].rfind(".")  
     returnValue['pattern'] = returnValue['pattern'][:last_char_index]+"}}"
     return returnValue


def replaceParamValues(agent,e,apiURL):
    regex = Constants.PATTERN_PARAM
    matches = re.finditer(regex, apiURL, re.MULTILINE | re.DOTALL)
    for matchNum, match in enumerate(matches):
        for groupNum in range(0, len(match.groups())):
            params = match.group(1)
            rootElement = params.split('.')
            found = False
            for key in e:
                if(rootElement[0] == key ):
                    found = True
                    break
            pattern = ""
            if(found):
                value={}
                try:
                    value = generateDotNotation(rootElement,e)
                    apiURL = apiURL.replace(value['pattern'],str(value['paramvalue']))
                except KeyError as ke:
                    last_char_index = value['pattern'].rfind(".")  
                    value['pattern'] = value['pattern'][:last_char_index]+"}}"
                    if(type(value['paramvalue']) != str):
                        apiURL = apiURL.replace(value['pattern'],"")
                except TypeError as e:
                    print("")
            else:
                value = generateDotNotation(rootElement)
                apiURL = apiURL.replace(value['pattern'],"")
                

    return apiURL             

def getAgentType(agent):
    if(agent[Constants.AGENTTYPE] == Constants.HTTPREQUESTAGENT):
        return Constants.HTTPREQUESTAGENT
    elif(agent[Constants.AGENTTYPE] == Constants.PRINTAGENT):
        return Constants.PRINTAGENT
        
def printFinalMessage(event):
     for k in event:
            if "print" in k:
                print(event[k])
