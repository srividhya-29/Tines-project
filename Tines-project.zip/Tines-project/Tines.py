import sys
import Constants
import TinesMethods

def main(argv):
    with open(argv,'r') as f:
            
                agents = TinesMethods.loadJSON(f)
                i =0
                e= {}
                if(agents != None):
                    for agent in agents:
                        if TinesMethods.getAgentType(agent) == Constants.HTTPREQUESTAGENT:
                            apiURL = agent[Constants.AGENTOPTIONS][Constants.AGENTURL]
                            if(i > 0):
                                apiURL = TinesMethods.replaceParamValues(agent,e,apiURL)
                            result = apiURL if TinesMethods.getHTTPRequest(apiURL) == None else TinesMethods.getHTTPRequest(apiURL)

                        elif TinesMethods.getAgentType(agent) == Constants.PRINTAGENT:
                            apiURL = agent[Constants.AGENTOPTIONS][Constants.AGENTMESSAGE]
                            result = TinesMethods.replaceParamValues(agent,e,apiURL)
                        e[agent[Constants.AGENTNAME]] = result    
                        i = i+1 
                else:
                    sys.exit(Constants.TERMINATION_MESSAGE)
               
    TinesMethods.printFinalMessage(e)
    
           
try:
    main(sys.argv[1])
except IndexError:
    print("Please enter a json file as an console argument")





